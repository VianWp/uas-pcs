package com.muhammadwahyudin.kadefootballapp.data.remote.response

import com.muhammadwahyudin.kadefootballapp.data.model.Standing

data class LeagueStandingsRes(
    val table: List<Standing>
)